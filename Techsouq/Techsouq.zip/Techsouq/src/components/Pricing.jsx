import React from 'react';
import Navbar_Main from './Navbar_Main';
import group from "../assets/Images/pricing.png";
import Group from "../assets/Images/pricing1.png";
import Questions1 from '../pages/Questions1';
import Questions2 from '../pages/Questions2';
import Last_page from '../pages/Last_page';
import Footer from './Footer';

const Pricing = () => {
  return (
    <>
      <Navbar_Main />
      <div className="relative h-screen">
        <div className="absolute inset-0 bg-black opacity-60 z-10"></div>
        <img
          src={group}
          className="absolute inset-0 w-full h-full object-cover z-0 rounded-br-6xl"
          alt="Background"
        />
        <div className="flex flex-col items-center justify-center text-center text-white relative z-20 h-full px-6 sm:px-12">
          <button className="btn px-4 py-2 sm:px-6 sm:py-3 border border-white rounded-full text-sm sm:text-base font-bold">
            Welcome To Techsouq
          </button>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mt-4">
            Flexible Pricing Plans For Every Business
          </h1>
          <h4 className="text-sm sm:text-base lg:text-lg mt-4 max-w-4xl">
            At Techsouq, we believe in transforming ideas into digital
            excellence. Driven by creativity and defined by results, we combine
            innovation, design, and technology to empower businesses in the
            digital landscape.
          </h4>
          <button className="btn px-6 py-3 rounded-xl bg-white flex items-center space-x-2 mt-6">
            <span className="bg-gradient-to-r from-[#9384FE] to-[#312EFE] text-transparent bg-clip-text font-bold text-sm sm:text-base">
              Book a consultation
            </span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="url(#gradient1)"
              className="w-5 h-5 sm:w-6 sm:h-6"
            >
              <defs>
                <linearGradient id="gradient1" x1="0" x2="1" y1="0" y2="0">
                  <stop offset="0%" stopColor="#9384FE" />
                  <stop offset="100%" stopColor="#312EFE" />
                </linearGradient>
              </defs>
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M17.25 8.25 21 12m0 0-3.75 3.75M21 12H3"
              />
            </svg>
          </button>
        </div>
      </div>
      <div className="max-w-screen-2xl container mx-auto xl:px-24 ">
              <div className="py-20 flex flex-col md:flex-row-reverse items-center justify-between gap-2">
                {/* texts */}
                <div className="md:w-1/2 px-2 space-y-4">
                  <button className="font-semibold btn bg-gradient-to-r inline-block text-transparent bg-clip-textbg-gradient-to-r from-[#9384Ef] to-[#312EFE] bg-clip-text px-6 py-3 text-xl border border-purple-700 rounded-full">
                    Custom
                  </button>
                  <div className="text-6xl font-bold">
                  Need Something Custom
                  </div>
                  <p className="text-[#4A4A4A] text-lg">
                  Every business is unique, and so are its needs. At Techsouq, we understand that a one-size-fits-all approach doesn't always work That's why we offer custom solutions tailored specifically to your goals, challenges, and vision Whether you need advanced features, additional support, or a completely bespoke plan, we're here to craft a solution that perfectly aligns with your business. Let us help you unlock your full potential with a plan built just for you.
                  </p>
    
                  <button className="bg-gradient-to-r from-[#9384Ef] to-[#312EFE] font-semibold btn text-white px-8 py-3 rounded-md flex justify-center gap-4 ">
                    Contact US Now
                    <svg
                      width="20"
                      height="20"
                      viewBox="0 0 20 20"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <g clip-path="url(#clip0_55_1110)">
                        <path
                          d="M0.953125 9.6377H16.7865"
                          stroke="white"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                        <path
                          d="M11.6641 4.16675L17.4974 10.0001L11.6641 15.8334"
                          stroke="white"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </g>
                      <defs>
                        <clipPath id="clip0_55_1110">
                          <rect width="20" height="20" fill="white" />
                        </clipPath>
                      </defs>
                    </svg>
                  </button>
                </div>
                {/* img */}
                <div className="md:w-1/3">
                  <img src={Group} alt="" className="rounded-xl" />
                </div>
              </div>
            </div>
            <div className="container mx-auto px-4 py-16 bg-slate-100">
      <h1 className="text-3xl font-bold text-center mb-8">
        Our Custom Pricing
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold mb-4">Lump Sum</h2>
          <p className="text-gray-600 mb-4">Starting at</p>
          <h3 className="text-4xl font-bold text-indigo-600 mb-4">
            $4000 <span className='text-slate-500 font-normal'>/month</span>
          </h3>
          
          <h4 className="text-lg font-bold mb-2">Package Includes</h4>
          <ul className="list-disc ml-6">
            <li>Custom Design</li>
            <li>Custom Development</li>
            <li>High Performance Hosting</li>
            <li>Unlimited Edits</li>
            <li>24/7 Customers Service</li>
            <li>Free Google Analytics Integration</li>
          </ul>
          <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md mt-6">
            Get Started
          </button>
        </div>
        <div className="bg-gradient-to-r from-[#9384Ef] to-[#312EFE] rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold mb-4 text-white">Starter</h2>
          <p className="text-white mb-4">Perfect to get started</p>
          <h3 className="text-4xl font-bold text-white mb-4">
            $200<span className='text-white font-normal'>/month</span>
          </h3>
          
          <h4 className="text-lg font-bold mb-2">Package Includes</h4>
 <ul className="list-disc ml-6">
            <li>Basic Design</li>
            <li>Responsive Layout</li>
            <li>Email Support</li>
            <li>1 Revision</li>
          </ul>
          <button className="btn px-6 py-3 rounded-xl bg-white flex items-center space-x-2 mt-6">
            <span className="bg-gradient-to-r from-[#9384FE] to-[#312EFE] text-transparent bg-clip-text font-bold text-sm sm:text-base">
              Subscribe
            </span>
            
          </button>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold mb-4">Enterprise</h2>
          <p className="text-gray-600 mb-4">For large organizations</p>
          <h3 className="text-4xl font-bold text-indigo-600 mb-4">
            $0 <span className='text-slate-500 font-normal'>/month</span>
          </h3>
          
          <h4 className="text-lg font-bold mb-2">Package Includes</h4>
          <ul className="list-disc ml-6">
            <li>Custom Design</li>
            <li>Dedicated Account Manager</li>
            <li>Performance Optimization</li>
            <li>Unlimited Revisions</li>
            <li>Priority Support</li>
            <li>Advanced Analytics</li>
          </ul>
          <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md mt-6">
            Get A Quote
          </button>
        </div>
      </div>
    </div>
            <Questions1/>
            <Questions2/>
            <Last_page/>
            <Footer/>
    </>
  )
}

export default Pricing

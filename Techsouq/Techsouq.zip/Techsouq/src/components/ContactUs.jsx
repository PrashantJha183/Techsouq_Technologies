import React from 'react';
import Navbar_Main from './Navbar_Main';
import group from "../assets/Images/contact.png";
import Questions1 from '../pages/Questions1';
import Questions2 from '../pages/Questions2';
import Last_page from '../pages/Last_page';
import Footer from './Footer';

function ContactUS() {
  return (
    <>
    <Navbar_Main/>
    <div className="relative h-screen">
            <div className="absolute inset-0 bg-black opacity-60 z-10"></div>
            <img
              src={group}
              className="absolute inset-0 w-full h-full object-cover z-0 rounded-br-6xl"
              alt="Background"
            />
            <div className="flex flex-col items-center justify-center text-center text-white relative z-20 h-full px-6 sm:px-12">
              <button className="btn px-4 py-2 sm:px-6 sm:py-3 border border-white rounded-full text-sm sm:text-base font-bold">
                Welcome To Techsouq
              </button>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mt-4">
                Contact Us For Valuable Feedback with Us
              </h1>
              <h4 className="text-sm sm:text-base lg:text-lg mt-4 max-w-4xl">
                At Techsouq, we believe in transforming ideas into digital
                excellence. Driven by creativity and defined by results, we combine
                innovation, design, and technology to empower businesses in the
                digital landscape.
              </h4>
              <button className="btn px-6 py-3 rounded-xl bg-white flex items-center space-x-2 mt-6">
                <span className="bg-gradient-to-r from-[#9384FE] to-[#312EFE] text-transparent bg-clip-text font-bold text-sm sm:text-base">
                  Book a consultation
                </span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="url(#gradient1)"
                  className="w-5 h-5 sm:w-6 sm:h-6"
                >
                  <defs>
                    <linearGradient id="gradient1" x1="0" x2="1" y1="0" y2="0">
                      <stop offset="0%" stopColor="#9384FE" />
                      <stop offset="100%" stopColor="#312EFE" />
                    </linearGradient>
                  </defs>
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M17.25 8.25 21 12m0 0-3.75 3.75M21 12H3"
                  />
                </svg>
              </button>
            </div>
          </div>
    <div className="bg-white rounded-lg shadow-lg p-8">
      {/* texts */}
      <div className="md:w-1/2 px-4 space-y-7 bg-slate-100">
      <h2 className="text-2xl font-bold mb-4 text-center mt-4">Send Message</h2>
      <p className="text-gray-600 text-center mb-6">
        Please fill out the form below. We will get back to you as soon as we
        can.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="firstName" className="block text-gray-700 text-sm font-bold mb-2">
            First Name
          </label>
          <input
            type="text"
            id="firstName"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            placeholder="John..."
            />
        </div>
        <div>
          <label htmlFor="lastName" className="block text-gray-700 text-sm font-bold mb-2">
            Last Name
          </label>
          <input
            type="text"
            id="lastName"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            placeholder="Last Name..."
            />
        </div>
        <div>
          <label htmlFor="phoneNumber" className="block text-gray-700 text-sm font-bold mb-2">
            Phone Number
          </label>
          <input
            type="tel"
            id="phoneNumber"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            placeholder="+151265 413654"
            />
        </div>
        <div>
          <label htmlFor="email" className="block text-gray-700 text-sm font-bold mb -2">
            Email
          </label>
          <input
            type="email"
            id="email"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            placeholder="example@example.com"
            />
        </div>
      </div>

      <div className="mt-4">
        <label htmlFor="message" className="block text-gray-700 text-sm font-bold mb-2">
          Message
        </label>
        <textarea
          id="message"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          rows="4"
          placeholder="Your message..."
          ></textarea>
      </div>

      <div className="mt-6">
      <button className="bg-gradient-to-r from-[#9384Ef] to-[#312EFE] font-semibold btn text-white px-8 py-3 rounded-md flex justify-center gap-4 mb-4">
            Submit Now
            
          </button>
          </div>
      </div>
    </div>
    <Questions1/>
    <Questions2/>
    <Last_page/>
    <Footer/>
</>
  );
}

export default ContactUS;

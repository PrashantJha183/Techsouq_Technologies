import React, { useEffect, useState } from "react";
import logo from "../assets/Images/logo.png";
import { Link } from "react-router-dom";
import { FaBars, FaTimes } from "react-icons/fa";

const Navbar_Main = () => {
  const [isSticky, setSticky] = useState(false);
  const [isMenuOpen, setMenuOpen] = useState(false);

  const handleClick = () => {
    window.scrollTo({ top: 0 });
  };

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      setSticky(offset > 0);
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const toggleMenu = () => {
    setMenuOpen(!isMenuOpen);
  };

  return (
    <>
      <div className={`sticky top-0 z-50 ${isSticky ? 'bg-slate-50' : 'bg-white'} shadow-md py-2 px-4 flex justify-between items-center`}>
        <div className="flex items-center">
          <Link to="/">
            <img src={logo} alt="Logo" className="h-20 w-auto rounded-full" />
          </Link>
        </div>
        <button onClick={toggleMenu} className="lg:hidden text-black text-3xl">
          {isMenuOpen ? <FaTimes /> : <FaBars />}
        </button>
        <div className="hidden md:flex space-x-8">
          <Link to="/" className="text-black hover:text-blue-500 active:text-violet-600 font-semibold text-xl">Home</Link>
          <Link to="/about" className="text-black hover:text-blue-500 active:text-violet-600 font-semibold text-xl">About</Link>
          <Link to="/services" className="text-black hover:text-blue-500 active:text-violet-600 font-semibold text-xl">Service</Link>
          <Link to="/pricing" className="text-black hover:text-blue-500 active:text-violet-600 font-semibold text-xl">Pricing</Link>
          <Link to="/caseStudy" className="text-black hover:text-blue-500 active:text-violet-600 font-semibold text-xl">Case Study</Link>
          
          <Link to="/contact" className="text-black hover:text-blue-500 active:text-violet-600 font-semibold text-xl">Contact</Link>
        </div>
        <div className="hidden md:flex">
          <button className="bg-gradient-to-r from-[#9384Ef] to-[#312EFE] font-semibold text-white px-8 py-3 rounded-md flex items-center gap-2">
            Contact US Now
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
              <g clipPath="url(#clip0_55_1110)">
                <path d="M0.953125 9.6377H16.7865" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M11.6641 4.16675L17.4974 10.0001L11.6641 15.8334" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </g>
              <defs>
                <clipPath id="clip0_55_1110">
                  <rect width="20" height="20" fill="white" />
                </clipPath>
              </defs>
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`lg:hidden ${isMenuOpen ? 'block' : 'hidden'} fixed top-16 left-0 w-full bg-slate-50 p-4 shadow-md z-40`}>
        <nav className="flex flex-col items-center space-y-4">
          <Link to="/" onClick={handleClick} className="text-2xl font-semibold text-black hover:text-violet-500 transition duration-300 hover:bg-gray-200 rounded-lg px-4 py-2">Home</Link>
          <Link to="/about" onClick={handleClick} className ="text-2xl font-semibold text-black hover:text-violet-500 transition duration-300 hover:bg-gray-200 rounded-lg px-4 py-2">About</Link>
          <Link to="/services" onClick={handleClick} className="text-2xl font-semibold text-black hover:text-violet-500 transition duration-300 hover:bg-gray-200 rounded-lg px-4 py-2">Service</Link>
          <Link to="/pricing" onClick={handleClick} className="text-2xl font-semibold text-black hover:text-violet-500 transition duration-300 hover:bg-gray-200 rounded-lg px-4 py-2">Pricing</Link>
          <Link to="/caseStudy" onClick={handleClick} className="text-2xl font-semibold text-black hover:text-violet-500 transition duration-300 hover:bg-gray-200 rounded-lg px-4 py-2">Case Study</Link>
          <Link to="/contact" onClick={handleClick} className="text-2xl font-semibold text-black hover:text-violet-500 transition duration-300 hover:bg-gray-200 rounded-lg px-4 py-2">Contact</Link>
        </nav>
      </div>
    </>
  );
};

export default Navbar_Main;
import React from "react";
import { useState } from "react";
import Man from "../assets/Images/imageaa.png";
import Group from "../assets/Images/service1.png";
import group from "../assets/Images/service.png";
import Navbar_Main from "./Navbar_Main";
import Questions1 from "../pages/Questions1";
import Questions2 from "../pages/Questions2";
import Last_page from "../pages/Last_page";
import Footer from "./Footer";
import Services from "../pages/Services";

const Service = () => {
  return (
    <>
      <Navbar_Main />
      <div className="relative h-screen">
        <div className="absolute inset-0 bg-black opacity-60 z-10"></div>
        <img
          src={group}
          className="absolute inset-0 w-full h-full object-cover z-0 rounded-br-6xl"
          alt="Background"
        />
        <div className="flex flex-col items-center justify-center text-center text-white relative z-20 h-full px-6 sm:px-12">
          <button className="btn px-4 py-2 sm:px-6 sm:py-3 border border-white rounded-full text-sm sm:text-base font-bold">
            Welcome To Techsouq
          </button>
          <h1 className="text-6xl font-bold mt-4">
            See Our Quality Services With Us
          </h1>
          <h4 className="text-sm sm:text-base lg:text-lg mt-4 max-w-4xl">
            At Techsouq, we believe in transforming ideas into digital
            excellence. Driven by creativity and defined by results, we combine
            innovation, design, and technology to empower businesses in the
            digital landscape.
          </h4>
          <button className="btn px-6 py-3 rounded-xl bg-white flex items-center space-x-2 mt-6">
            <span className="bg-gradient-to-r from-[#9384FE] to-[#312EFE] text-transparent bg-clip-text font-bold text-sm sm:text-base">
              Book a consultation
            </span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="url(#gradient1)"
              className="w-5 h-5 sm:w-6 sm:h-6"
            >
              <defs>
                <linearGradient id="gradient1" x1="0" x2="1" y1="0" y2="0">
                  <stop offset="0%" stopColor="#9384FE" />
                  <stop offset="100%" stopColor="#312EFE" />
                </linearGradient>
              </defs>
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M17.25 8.25 21 12m0 0-3.75 3.75M21 12H3"
              />
            </svg>
          </button>
        </div>
      </div>
      <div className="max-w-screen-2xl container mx-auto xl:px-24 ">
        <div className="py-20 flex flex-col md:flex-row-reverse items-center justify-between gap-2">
          {/* texts */}
          <div className="md:w-1/2 px-2 space-y-4">
          <button className="font-semibold btn bg-gradient-to-r inline-block text-transparent bg-clip-textbg-gradient-to-r from-[#9384Ef] to-[#312EFE] bg-clip-text px-6 py-2 text-lg border border-purple-700 rounded-full">
              Why Choose
            </button>
            <div className="text-6xl font-bold">Why Choose Our Services</div>
            <div className="flex items-center mt-4">
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 18 18"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clip-path="url(#clip0_55_608)">
                    <path
                      d="M16.5 8.30999V8.99999C16.4991 10.6173 15.9754 12.191 15.007 13.4864C14.0386 14.7817 12.6775 15.7293 11.1265 16.1879C9.57557 16.6465 7.91794 16.5914 6.40085 16.0309C4.88376 15.4704 3.58849 14.4346 2.70822 13.0778C1.82795 11.721 1.40984 10.116 1.51626 8.50223C1.62267 6.88841 2.24791 5.35223 3.29871 4.12279C4.34951 2.89335 5.76959 2.03653 7.34714 1.6801C8.92469 1.32367 10.5752 1.48674 12.0525 2.14499"
                      stroke="url(#paint0_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <path
                      d="M16.5 3L9 10.5075L6.75 8.2575"
                      stroke="url(#paint1_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </g>
                  <defs>
                    <linearGradient
                      id="paint0_linear_55_608"
                      x1="6.28022"
                      y1="6.27592"
                      x2="14.4396"
                      y2="16.4957"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <linearGradient
                      id="paint1_linear_55_608"
                      x1="9.85714"
                      y1="5.3925"
                      x2="13.5938"
                      y2="11.4708"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <clipPath id="clip0_55_608">
                      <rect width="18" height="18" fill="white" />
                    </clipPath>
                  </defs>
                </svg>

                <span className="ml-2 text-gray-700">Research and Discovery</span>
              </div>
            <div className="flex items-center">
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 18 18"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clip-path="url(#clip0_55_608)">
                    <path
                      d="M16.5 8.30999V8.99999C16.4991 10.6173 15.9754 12.191 15.007 13.4864C14.0386 14.7817 12.6775 15.7293 11.1265 16.1879C9.57557 16.6465 7.91794 16.5914 6.40085 16.0309C4.88376 15.4704 3.58849 14.4346 2.70822 13.0778C1.82795 11.721 1.40984 10.116 1.51626 8.50223C1.62267 6.88841 2.24791 5.35223 3.29871 4.12279C4.34951 2.89335 5.76959 2.03653 7.34714 1.6801C8.92469 1.32367 10.5752 1.48674 12.0525 2.14499"
                      stroke="url(#paint0_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <path
                      d="M16.5 3L9 10.5075L6.75 8.2575"
                      stroke="url(#paint1_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </g>
                  <defs>
                    <linearGradient
                      id="paint0_linear_55_608"
                      x1="6.28022"
                      y1="6.27592"
                      x2="14.4396"
                      y2="16.4957"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <linearGradient
                      id="paint1_linear_55_608"
                      x1="9.85714"
                      y1="5.3925"
                      x2="13.5938"
                      y2="11.4708"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <clipPath id="clip0_55_608">
                      <rect width="18" height="18" fill="white" />
                    </clipPath>
                  </defs>
                </svg>

                <span className="ml-2 text-gray-700">Strategy Development</span>
              </div>
            <div className="flex items-center">
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 18 18"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clip-path="url(#clip0_55_608)">
                    <path
                      d="M16.5 8.30999V8.99999C16.4991 10.6173 15.9754 12.191 15.007 13.4864C14.0386 14.7817 12.6775 15.7293 11.1265 16.1879C9.57557 16.6465 7.91794 16.5914 6.40085 16.0309C4.88376 15.4704 3.58849 14.4346 2.70822 13.0778C1.82795 11.721 1.40984 10.116 1.51626 8.50223C1.62267 6.88841 2.24791 5.35223 3.29871 4.12279C4.34951 2.89335 5.76959 2.03653 7.34714 1.6801C8.92469 1.32367 10.5752 1.48674 12.0525 2.14499"
                      stroke="url(#paint0_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <path
                      d="M16.5 3L9 10.5075L6.75 8.2575"
                      stroke="url(#paint1_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </g>
                  <defs>
                    <linearGradient
                      id="paint0_linear_55_608"
                      x1="6.28022"
                      y1="6.27592"
                      x2="14.4396"
                      y2="16.4957"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <linearGradient
                      id="paint1_linear_55_608"
                      x1="9.85714"
                      y1="5.3925"
                      x2="13.5938"
                      y2="11.4708"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <clipPath id="clip0_55_608">
                      <rect width="18" height="18" fill="white" />
                    </clipPath>
                  </defs>
                </svg>

                <span className="ml-2 text-gray-700">Design and Development</span>
              </div>
            <div className="flex items-center">
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 18 18"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clip-path="url(#clip0_55_608)">
                    <path
                      d="M16.5 8.30999V8.99999C16.4991 10.6173 15.9754 12.191 15.007 13.4864C14.0386 14.7817 12.6775 15.7293 11.1265 16.1879C9.57557 16.6465 7.91794 16.5914 6.40085 16.0309C4.88376 15.4704 3.58849 14.4346 2.70822 13.0778C1.82795 11.721 1.40984 10.116 1.51626 8.50223C1.62267 6.88841 2.24791 5.35223 3.29871 4.12279C4.34951 2.89335 5.76959 2.03653 7.34714 1.6801C8.92469 1.32367 10.5752 1.48674 12.0525 2.14499"
                      stroke="url(#paint0_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <path
                      d="M16.5 3L9 10.5075L6.75 8.2575"
                      stroke="url(#paint1_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </g>
                  <defs>
                    <linearGradient
                      id="paint0_linear_55_608"
                      x1="6.28022"
                      y1="6.27592"
                      x2="14.4396"
                      y2="16.4957"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <linearGradient
                      id="paint1_linear_55_608"
                      x1="9.85714"
                      y1="5.3925"
                      x2="13.5938"
                      y2="11.4708"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <clipPath id="clip0_55_608">
                      <rect width="18" height="18" fill="white" />
                    </clipPath>
                  </defs>
                </svg>

                <span className="ml-2 text-gray-700">Testing and Optimization</span>
              </div>
            <div className="flex items-center">
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 18 18"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clip-path="url(#clip0_55_608)">
                    <path
                      d="M16.5 8.30999V8.99999C16.4991 10.6173 15.9754 12.191 15.007 13.4864C14.0386 14.7817 12.6775 15.7293 11.1265 16.1879C9.57557 16.6465 7.91794 16.5914 6.40085 16.0309C4.88376 15.4704 3.58849 14.4346 2.70822 13.0778C1.82795 11.721 1.40984 10.116 1.51626 8.50223C1.62267 6.88841 2.24791 5.35223 3.29871 4.12279C4.34951 2.89335 5.76959 2.03653 7.34714 1.6801C8.92469 1.32367 10.5752 1.48674 12.0525 2.14499"
                      stroke="url(#paint0_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <path
                      d="M16.5 3L9 10.5075L6.75 8.2575"
                      stroke="url(#paint1_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </g>
                  <defs>
                    <linearGradient
                      id="paint0_linear_55_608"
                      x1="6.28022"
                      y1="6.27592"
                      x2="14.4396"
                      y2="16.4957"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <linearGradient
                      id="paint1_linear_55_608"
                      x1="9.85714"
                      y1="5.3925"
                      x2="13.5938"
                      y2="11.4708"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <clipPath id="clip0_55_608">
                      <rect width="18" height="18" fill="white" />
                    </clipPath>
                  </defs>
                </svg>

                <span className="ml-2 text-gray-700">Launch and Support</span>
              </div>
              <div>
            <button className="bg-gradient-to-r from-[#9384Ef] to-[#312EFE] font-semibold btn text-white px-8 py-3 rounded-md flex justify-center gap-4 mt-8">
              Contact Us Now
              <svg
                width="20"
                height="20"
                viewBox="0 0 20 20"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                >
                <g clip-path="url(#clip0_55_1110)">
                  <path
                    d="M0.953125 9.6377H16.7865"
                    stroke="white"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    />
                  <path
                    d="M11.6641 4.16675L17.4974 10.0001L11.6641 15.8334"
                    stroke="white"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    />
                </g>
                <defs>
                  <clipPath id="clip0_55_1110">
                    <rect width="20" height="20" fill="white" />
                  </clipPath>
                </defs>
              </svg>
            </button>

                    </div>
          </div>
          {/* img */}
          <div className="md:w-1/3">
            <img src={Group} alt="" className="rounded-xl" />
          </div>
        </div>
      </div>
      <div className="max-w-screen-2xl container mx-auto xl:px-24 ">
        <div className="py-10 flex flex-col md:flex-row-reverse items-center justify-between gap-2">
          {/* img */}
          <div className="md:w-1/3">
            <img src={Man} alt="" className="rounded-xl" />
          </div>
          {/* texts */}
          <div className="md:w-1/2 px-2 space-y-4">
          <button className="font-semibold btn bg-gradient-to-r inline-block text-transparent bg-clip-textbg-gradient-to-r from-[#9384Ef] to-[#312EFE] bg-clip-text px-6 py-2 text-lg border border-purple-700 rounded-full">
              Why Choose Us
            </button>
            <div className="text-6xl font-bold">
              What Makes Techsouq the Right Choice?
            </div>
            <p className="text-[#4A4A4A] text-base py-4">
              Our expertise and commitment ensure exceptional results.
            </p>
            <div className="flex gap-4 mb-4">
              <div className="flex items-center">
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 18 18"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clip-path="url(#clip0_55_608)">
                    <path
                      d="M16.5 8.30999V8.99999C16.4991 10.6173 15.9754 12.191 15.007 13.4864C14.0386 14.7817 12.6775 15.7293 11.1265 16.1879C9.57557 16.6465 7.91794 16.5914 6.40085 16.0309C4.88376 15.4704 3.58849 14.4346 2.70822 13.0778C1.82795 11.721 1.40984 10.116 1.51626 8.50223C1.62267 6.88841 2.24791 5.35223 3.29871 4.12279C4.34951 2.89335 5.76959 2.03653 7.34714 1.6801C8.92469 1.32367 10.5752 1.48674 12.0525 2.14499"
                      stroke="url(#paint0_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <path
                      d="M16.5 3L9 10.5075L6.75 8.2575"
                      stroke="url(#paint1_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </g>
                  <defs>
                    <linearGradient
                      id="paint0_linear_55_608"
                      x1="6.28022"
                      y1="6.27592"
                      x2="14.4396"
                      y2="16.4957"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <linearGradient
                      id="paint1_linear_55_608"
                      x1="9.85714"
                      y1="5.3925"
                      x2="13.5938"
                      y2="11.4708"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <clipPath id="clip0_55_608">
                      <rect width="18" height="18" fill="white" />
                    </clipPath>
                  </defs>
                </svg>

                <span className="ml-2 text-gray-700">Years of Experience</span>
              </div>
              <div className="flex items-center">
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 18 18"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clip-path="url(#clip0_55_608)">
                    <path
                      d="M16.5 8.30999V8.99999C16.4991 10.6173 15.9754 12.191 15.007 13.4864C14.0386 14.7817 12.6775 15.7293 11.1265 16.1879C9.57557 16.6465 7.91794 16.5914 6.40085 16.0309C4.88376 15.4704 3.58849 14.4346 2.70822 13.0778C1.82795 11.721 1.40984 10.116 1.51626 8.50223C1.62267 6.88841 2.24791 5.35223 3.29871 4.12279C4.34951 2.89335 5.76959 2.03653 7.34714 1.6801C8.92469 1.32367 10.5752 1.48674 12.0525 2.14499"
                      stroke="url(#paint0_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <path
                      d="M16.5 3L9 10.5075L6.75 8.2575"
                      stroke="url(#paint1_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </g>
                  <defs>
                    <linearGradient
                      id="paint0_linear_55_608"
                      x1="6.28022"
                      y1="6.27592"
                      x2="14.4396"
                      y2="16.4957"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <linearGradient
                      id="paint1_linear_55_608"
                      x1="9.85714"
                      y1="5.3925"
                      x2="13.5938"
                      y2="11.4708"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <clipPath id="clip0_55_608">
                      <rect width="18" height="18" fill="white" />
                    </clipPath>
                  </defs>
                </svg>

                <span className="ml-2 text-gray-700">Tailored Strategies</span>
              </div>
              <div className="flex items-center">
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 18 18"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clip-path="url(#clip0_55_608)">
                    <path
                      d="M16.5 8.30999V8.99999C16.4991 10.6173 15.9754 12.191 15.007 13.4864C14.0386 14.7817 12.6775 15.7293 11.1265 16.1879C9.57557 16.6465 7.91794 16.5914 6.40085 16.0309C4.88376 15.4704 3.58849 14.4346 2.70822 13.0778C1.82795 11.721 1.40984 10.116 1.51626 8.50223C1.62267 6.88841 2.24791 5.35223 3.29871 4.12279C4.34951 2.89335 5.76959 2.03653 7.34714 1.6801C8.92469 1.32367 10.5752 1.48674 12.0525 2.14499"
                      stroke="url(#paint0_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <path
                      d="M16.5 3L9 10.5075L6.75 8.2575"
                      stroke="url(#paint1_linear_55_608)"
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </g>
                  <defs>
                    <linearGradient
                      id="paint0_linear_55_608"
                      x1="6.28022"
                      y1="6.27592"
                      x2="14.4396"
                      y2="16.4957"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <linearGradient
                      id="paint1_linear_55_608"
                      x1="9.85714"
                      y1="5.3925"
                      x2="13.5938"
                      y2="11.4708"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stop-color="#9384FE" />
                      <stop offset="1" stop-color="#312EFE" />
                    </linearGradient>
                    <clipPath id="clip0_55_608">
                      <rect width="18" height="18" fill="white" />
                    </clipPath>
                  </defs>
                </svg>

                <span className="ml-2 text-gray-700">
                  Passionate Skilled Team
                </span>
              </div>
            </div>
            <div className="flex justify-start py-4">
              <button className="bg-gradient-to-r from-[#9384Ef] to-[#312EFE] font-semibold btn text-white px-8 py-3 rounded-md flex justify-center gap-4">
                Contact US Now
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 20 20"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clipPath="url(#clip0_55_1110)">
                    <path
                      d="M0.953125 9.6377H16.7865"
                      stroke="white"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M11.6641 4.16675L17.4974 10.0001L11.6641 15.8334"
                      stroke="white"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </g>
                  <defs>
                    <clipPath id="clip0_55_1110">
                      <rect width="20" height="20" fill="white" />
                    </clipPath>
                  </defs>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
      <Services />
      <Questions1 />
      <Questions2 />
      <Last_page />
      <Footer />
    </>
  );
};

export default Service;

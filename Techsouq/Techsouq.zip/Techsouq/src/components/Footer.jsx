import React from "react";
import logo from "../assets/Images/logo.png";

function Footer() {
  return (
    <div className="bg-gray-100">
      <header className="py-8 px-4">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-start md:items-center">
          <div className="mb-6 md:mb-0">
            <img src={logo} alt="Techsouq logo" className="h-10" />
            <h1 className="text-xl md:text-2xl font-bold mt-2">
              Subscribe For More Updates
            </h1>
            <div className="mt-4 flex flex-col md:flex-row">
              <input
                type="email"
                placeholder="Enter your Email here"
                className="border border-gray-300 px-4 py-2 rounded-l-md mb-2 md:mb-0 md:mr-2"
              />
              <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md">
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 20 20"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clipPath="url(#clip0_55_1110)">
                    <path
                      d="M0.953125 9.6377H16.7865"
                      stroke="white"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M11.6641 4.16675L17.4974 10.0001L11.6641 15.8334"
                      stroke="white"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </g>
                  <defs>
                    <clipPath id="clip0_55_1110">
                      <rect width="20" height="20" fill="white" />
                    </clipPath>
                  </defs>
                </svg>
              </button>
            </div>
            <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-12">
              <div>
                <h2 className="text-lg font-bold mb-2 mt-4">Address</h2>
                <div className="mb-4">
                  <div className="flex items-center">
                    <svg
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M17.6297 22.4631C16.7353 22.3831 15.9516 22.1856 15.1853 21.9175C12.9503 21.1356 10.9866 19.8875 9.17406 18.3875C6.66281 16.3081 4.56781 13.8787 3.03156 10.99C2.36281 9.7325 1.86344 8.41313 1.60781 7.00438C1.52406 6.5425 1.57094 6.145 1.84719 5.74813C2.80031 4.38313 3.83906 3.09375 5.06594 1.9625C5.19719 1.84188 5.34156 1.7325 5.49031 1.63375C5.78219 1.43938 5.98594 1.45188 6.25094 1.68375C6.37344 1.79063 6.49094 1.90938 6.58469 2.04188C7.54031 3.39063 8.42656 4.78313 9.13593 6.27938C9.51906 7.0875 9.48093 7.22563 8.80968 7.82313C8.36718 8.21688 7.92656 8.61188 7.48031 9.00063C7.35656 9.10813 7.34219 9.21438 7.38844 9.36875C8.01344 11.4431 9.17969 13.1606 10.8297 14.5481C11.9622 15.5 13.2272 16.2206 14.6641 16.6187C14.8041 16.6575 14.8953 16.6419 14.9897 16.5338C15.3641 16.1056 15.7478 15.6862 16.1209 15.2575C16.7691 14.5131 16.9116 14.47 17.7928 14.8969C19.2403 15.5981 20.6034 16.4438 21.9078 17.3813C22.6553 17.9188 22.6847 18.2313 22.0653 18.9062C20.8791 20.1987 19.5347 21.3075 18.0628 22.2606C17.9103 22.3575 17.7322 22.4156 17.6297 22.4631Z"
                        fill="url(#paint0_linear_55_128)"
                      />
                      <path
                        d="M12.7812 2.98663C12.7812 2.48163 12.7812 2.00726 12.7812 1.53226C17.6262 1.33101 22.5431 5.57538 22.4894 11.2135C22.0037 11.2135 21.5181 11.2135 21.0169 11.2135C20.965 8.96038 20.1856 7.00788 18.5912 5.41288C16.9969 3.81788 15.0463 3.03663 12.7812 2.98663Z"
                        fill="url(#paint1_linear_55_128)"
                      />
                      <path
                        d="M18.7422 11.2227C18.2509 11.2227 17.7766 11.2227 17.3072 11.2227C17.0191 8.50084 15.5259 6.99584 12.7891 6.69521C12.7891 6.23521 12.7891 5.74896 12.7891 5.26334C15.9397 5.16396 18.8184 7.93334 18.7422 11.2227Z"
                        fill="url(#paint2_linear_55_128)"
                      />
                      <defs>
                        <linearGradient
                          id="paint0_linear_55_128"
                          x1="8.2407"
                          y1="8.17923"
                          x2="19.6489"
                          y2="22.4451"
                          gradientUnits="userSpaceOnUse"
                        >
                          <stop stopColor="#9384FE" />
                          <stop offset="1" stopColor="#312EFE" />
                        </linearGradient>
                        <linearGradient
                          id="paint1_linear_55_128"
                          x1="15.8752"
                          y1="4.61281"
                          x2="21.1426"
                          y2="11.2243"
                          gradientUnits="userSpaceOnUse"
                        >
                          <stop stopColor="#9384FE" />
                          <stop offset="1" stopColor="#312EFE" />
                        </linearGradient>
                        <linearGradient
                          id="paint2_linear_55_128"
                          x1="14.6867"
                          y1="7.16071"
                          x2="17.9306"
                          y2="11.2188"
                          gradientUnits="userSpaceOnUse"
                        >
                          <stop stopColor="#9384FE" />
                          <stop offset="1" stopColor="# 312EFE" />
                        </linearGradient>
                      </defs>
                    </svg>
                    <span className="ml-2 text-gray-700">(+91) 9978600505</span>
                  </div>
                  <div className="flex items-center mt-2">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.9485 23.9995C10.6005 23.9696 10.2525 23.938 9.90441 23.9105C8.23741 23.778 6.5962 23.5091 5.00831 22.97C4.12706 22.6712 3.26866 22.3097 2.55968 21.6921C2.24796 21.4202 1.95441 21.0962 1.74933 20.7399C1.29757 19.9542 1.45636 19.0501 2.10558 18.3235C2.76241 17.5888 3.60558 17.1376 4.51027 16.8007C5.10675 16.5786 5.72843 16.4233 6.3337 16.2235C6.49484 16.1702 6.56515 16.2171 6.64894 16.3489C7.76691 18.1032 8.89191 19.8523 10.0116 21.6054C10.4364 22.2698 11.0194 22.6823 11.8163 22.7462C12.6747 22.8148 13.3948 22.5177 13.8847 21.8081C14.4776 20.9497 15.022 20.0573 15.5857 19.179C16.1874 18.2415 16.7909 17.3052 17.3827 16.3612C17.4806 16.2054 17.5679 16.1825 17.7384 16.2276C18.7872 16.5054 19.8185 16.8259 20.7612 17.379C21.2968 17.6931 21.7825 18.0657 22.1446 18.5808C22.7464 19.4374 22.6626 20.4903 21.9519 21.2626C21.346 21.9212 20.5931 22.3483 19.7827 22.687C18.3044 23.3052 16.7499 23.6192 15.1679 23.8062C14.5497 23.8794 13.9257 23.9093 13.3046 23.9608C13.236 23.9667 13.1687 23.9855 13.1007 23.9983C12.3829 23.9995 11.6657 23.9995 10.9485 23.9995Z" fill="url(#paint0_linear_168_2927)"/>
<path d="M4.30557 7.79191C4.37178 5.56652 5.10421 3.78937 6.54971 2.3298C7.74737 1.12043 9.20284 0.386248 10.8939 0.140154C12.8339 -0.142268 14.6345 0.251482 16.2657 1.32961C17.9257 2.42648 19.0208 3.95402 19.5007 5.88937C20.0339 8.03918 19.7023 10.0677 18.5105 11.9368C16.5921 14.945 14.6579 17.9433 12.7302 20.9462C12.6921 21.0054 12.6569 21.0663 12.6159 21.1226C12.3001 21.5544 11.7423 21.5591 11.4353 21.1214C11.2208 20.8155 11.028 20.4945 10.8265 20.1792C9.05284 17.4112 7.2751 14.6456 5.50733 11.8741C4.68116 10.5798 4.28331 9.15773 4.30557 7.79191ZM15.5327 7.76496C15.5321 5.83429 13.9483 4.25344 12.0183 4.25754C10.0964 4.26164 8.52315 5.83254 8.51671 7.75441C8.51026 9.68449 10.0888 11.27 12.0194 11.2736C13.9501 11.2771 15.5333 9.69562 15.5327 7.76496Z" fill="url(#paint1_linear_168_2927)"/>
<defs>
<linearGradient id="paint0_linear_168_2927" x1="8.20161" y1="18.6869" x2="10.567" y2="26.6865" gradientUnits="userSpaceOnUse">
<stop stop-color="#9384FE"/>
<stop offset="1" stop-color="#312EFE"/>
</linearGradient>
<linearGradient id="paint1_linear_168_2927" x1="9.22599" y1="6.87036" x2="21.1004" y2="17.6049" gradientUnits="userSpaceOnUse">
<stop stop-color="#9384FE"/>
<stop offset="1" stop-color="#312EFE"/>
</linearGradient>
</defs>
</svg>

                    <span className="ml-2 text-gray-700">TECHSOUQ TECHNOLOGIES PRIVATE LIMITED
SHOP NO . 2 <br></br>1ST FLOOR
OPP SBI BANK GALI
PORBANDAR
RANAVAV
PORBANDAR-360550
GUJARAT</span>
                  </div>
                  <div className="flex items-center mt-2">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M11.9672 20.3545C9.7453 20.3545 7.52342 20.3607 5.30155 20.3526C3.31467 20.3451 1.68905 19.0076 1.2878 17.0614C1.23967 16.8264 1.2153 16.582 1.21467 16.3426C1.20967 13.4739 1.21092 10.6045 1.21155 7.73573C1.21155 7.15823 1.33717 6.60823 1.57717 6.08385C1.74092 5.7251 1.7828 5.7176 2.05592 5.99073C4.10092 8.03635 6.14967 10.0782 8.18905 12.1289C9.24092 13.1864 10.4997 13.7551 11.9928 13.7501C13.4409 13.7457 14.6772 13.2089 15.7015 12.1839C17.7465 10.1382 19.7922 8.09323 21.8372 6.04823C21.8815 6.00385 21.9247 5.95885 21.9697 5.91635C22.144 5.75073 22.2109 5.75885 22.3165 5.97073C22.5678 6.47198 22.7278 7.00385 22.7297 7.56323C22.7384 10.5339 22.7534 13.5039 22.7272 16.4745C22.7109 18.3582 21.1472 20.0639 19.2847 20.3057C19.0303 20.3389 18.7722 20.3532 18.5159 20.3539C16.3328 20.3564 14.1497 20.3545 11.9672 20.3545Z" fill="url(#paint0_linear_55_135)"/>
<path d="M11.9704 3.69232C14.1686 3.69232 16.3673 3.69607 18.5654 3.69044C19.3979 3.68857 20.1667 3.89232 20.8673 4.34482C21.1048 4.49857 21.1098 4.54669 20.9061 4.74982C18.7898 6.86732 16.6767 8.98732 14.5567 11.1004C13.1142 12.5379 10.8523 12.5511 9.40793 11.1173C7.2723 8.99794 5.15043 6.86357 3.02355 4.73482C2.83543 4.54607 2.8423 4.49732 3.07418 4.34732C3.71793 3.93232 4.4223 3.69919 5.18855 3.69732C7.44918 3.68982 9.7098 3.69482 11.9704 3.69482C11.9704 3.69419 11.9704 3.69294 11.9704 3.69232Z" fill="url(#paint1_linear_55_135)"/>
<defs>
<linearGradient id="paint0_linear_55_135" x1="8.07247" y1="10.4382" x2="14.8613" y2="23.0143" gradientUnits="userSpaceOnUse">
<stop stop-color="#9384FE"/>
<stop offset="1" stop-color="#312EFE"/>
</linearGradient>
<linearGradient id="paint1_linear_55_135" x1="8.67849" y1="6.39769" x2="11.7846" y2="14.715" gradientUnits="userSpaceOnUse">
<stop stop-color="#9384FE"/>
<stop offset="1" stop-color="#312EFE"/>
</linearGradient>
</defs>
</svg>

                    <span className="ml-2 text-gray-700 mt-2">
                      info@techsouqtechnologies.com
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-12">
            <div>
              <h2 className="text-lg font-bold mb-2">Company</h2>
              <ul>
                <li className="mb-1">
                  <a href="#" className="text-gray-600 hover:text-blue-500">
                    → About Us
                  </a>
                </li>
                <li className="mb-1">
                  <a href="#" className="text-gray-600 hover:text-blue-500">
                    → Leadership
                  </a>
                </li>
                <li className="mb-1">
                  <a href="#" className="text-gray-600 hover:text-blue-500">
                    → Our Values
                  </a>
                </li>
                <li className="mb-1">
                  <a href="#" className="text-gray-600 hover:text-blue-500">
                    → Events
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-600 hover:text-blue-500">
                    → Blog
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h2 className="text-lg font-bold mb-2">Help</h2>
              <ul>
                <li className="mb-1">
                  <a href="#" className="text-gray-600 hover:text-blue-500">
                    → Terms & Condition
                  </a>
                </li>
                <li className="mb-1">
                  <a href="#" className="text-gray-600 hover:text-blue-500">
                    → Privacy Policy
                  </a>
                </li>
                <li className="mb-1">
                  <a href="#" className="text-gray-600 hover:text-blue-500">
                    → Customer Support
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-600 hover:text-blue-500">
                    → Career
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-600 hover:text-blue-500">
                    → Security
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h2 className="text-lg font-bold mb-2">Connect With Us</h2>
              <div className="mb-4">
                <div className="flex items-center">
                  <button>
                    <svg
                      width="36"
                      height="36"
                      viewBox="0 0 36 36"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <rect
                        x="0.5"
                        y="0.5"
                        width="35"
                        height="35"
                        rx="17.5"
                        stroke="url(#paint0_linear_55_145)"
                      />
                      <path
                        d="M15.3252 27L15.3 19.125H12V15.75H15.3V13.5C15.3 10.4634 17.1387 9 19.7873 9C21.056 9 22.1465 9.0966 22.4642 9.13978V12.3132L20.6273 12.3141C19.1868 12.3141 18.9079 13.0141 18.9079 14.0414V15.75H23L21.9 19.125H18.9078V27H15.3252Z"
                        fill="url(#paint1_linear_55_145)"
                      />
                      <defs>
                        <linearGradient
                          id="paint0_linear_55_145"
                          x1="11.4725"
                          y1="11.4725"
                          x2="31.0549"
                          y2="36"
                          gradientUnits="userSpaceOnUse"
                        >
                          <stop stopColor="#9384FE" />
                          <stop offset="1" stopColor="#312EFE" />
                        </linearGradient>
                        <linearGradient
                          id="paint1_linear_55_145"
                          x1="15.5055"
                          y1="14.7363"
                          x2="25.1976"
                          y2="22.1549"
                          gradientUnits="userSpaceOnUse"
                        >
                          <stop stopColor="#9384FE" />
                          <stop offset="1" stopColor="#312EFE" />
                        </linearGradient>
                      </defs>
                    </svg>
                  </button>
                  <span className="ml-2 text-gray-700">Facebook</span>
                </div>
                <div className="flex items-center mt-2">
                  <button>
                    <svg
                      width="36"
                      height="36"
                      viewBox="0 0 36 36"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <rect
                        x="0.5"
                        y="0.5"
                        width="35"
                        height="35"
                        rx="17.5"
                        stroke="url(#paint0_linear_55_149)"
                      />
                      <path
                        d="M27 12.6589C26.3363 12.9396 25.6268 13.1292 24.8792 13.2167C25.6421 12.7792 26.2295 12.0865 26.5041 11.2625C25.7908 11.6672 25.0013 11.9625 24.1583 12.1193C23.4832 11.4302 22.5219 11 21.4615 11C19.4209 11 17.7692 12.5823 17.7692 14.5328C17.7692 14.8099 17.7997 15.0797 17.8646 15.3385C14.794 15.1927 12.0706 13.7854 10.2511 11.6453C9.93452 12.1667 9.75143 12.7755 9.75143 13.4208C9.75143 14.6458 10.4075 15.7286 11.3992 16.363C10.7889 16.3484 10.2168 16.188 9.72092 15.9219V15.9656C9.72092 17.6792 10.9949 19.1047 12.6847 19.4292C12.3757 19.5094 12.0477 19.5531 11.712 19.5531C11.4755 19.5531 11.2428 19.5312 11.0178 19.4875C11.487 20.8911 12.8525 21.912 14.4698 21.9411C13.2072 22.8891 11.6128 23.4542 9.88112 23.4542C9.5836 23.4542 9.28989 23.4359 9 23.4031C10.6287 24.4167 12.5702 25 14.6529 25C21.4539 25 25.1691 19.6151 25.1691 14.9448C25.1691 14.7917 25.1653 14.6385 25.1577 14.4891C25.8786 13.9896 26.5041 13.3698 27 12.6589Z"
                        fill="url(#paint1_linear_55_149)"
                      />
                      <defs>
                        <linearGradient
                          id="paint0_linear_55_149"
                          x1="11.4725"
                          y1="11.4725"
                          x2="31.0549"
                          y2="36"
                          gradientUnits="userSpaceOnUse"
                        >
                          <stop stop-color="#9384FE" />
                          <stop offset="1" stop-color="#312EFE" />
                        </linearGradient>
                        <linearGradient
                          id="paint1_linear_55_149"
                          x1="14.7363"
                          y1="15.4615"
                          x2="21.7358"
                          y2="26.7335"
                          gradientUnits="userSpaceOnUse"
                        >
                          <stop stop-color="#9384FE" />
                          <stop offset="1" stop-color="#312EFE" />
                        </linearGradient>
                      </defs>
                    </svg>
                  </button>
                  <span className="ml-2 text-gray-700 mt-2">Twitter</span>
                </div>
                <div className="flex items-center mt-2">
                  <button>
                    <svg
                      width="36"
                      height="36"
                      viewBox="0 0 36 36"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <rect
                        x="0.5"
                        y="0.5"
                        width="35"
                        height="35"
                        rx="17.5"
                        stroke="url(#paint0_linear_55_153)"
                      />
                      <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M26.235 13.5675C25.7467 12.699 25.2169 12.5393 24.138 12.4785C23.0603 12.4054 20.3501 12.375 18.0022 12.375C15.6499 12.375 12.9386 12.4054 11.862 12.4774C10.7854 12.5393 10.2544 12.6979 9.76162 13.5675C9.25875 14.4349 9 15.9289 9 18.5591V18.5681C9 21.1871 9.25875 22.6924 9.76162 23.5507C10.2544 24.4193 10.7843 24.5768 11.8609 24.6499C12.9386 24.7129 15.6499 24.75 18.0022 24.75C20.3501 24.75 23.0602 24.7129 24.1391 24.651C25.218 24.5779 25.7479 24.4204 26.2361 23.5519C26.7435 22.6935 27 21.1882 27 18.5692V18.5603C27 15.9289 26.7435 14.4349 26.235 13.5675ZM15.75 21.9375V15.1875L21.375 18.5625L15.75 21.937 ```javascript
5Z"
                        fill="url(#paint1_linear_55_153)"
                      />
                      <defs>
                        <linearGradient
                          id="paint0_linear_55_153"
                          x1="11.4725"
                          y1="11.4725"
                          x2="31.0549"
                          y2="36"
                          gradientUnits="userSpaceOnUse"
                        >
                          <stop stopColor="#9384FE" />
                          <stop offset="1" stopColor="#312EFE" />
                        </linearGradient>
                        <linearGradient
                          id="paint1_linear_55_153"
                          x1="14.7363"
                          y1="16.3187"
                          x2="20.5596"
                          y2="26.9279"
                          gradientUnits="userSpaceOnUse"
                        >
                          <stop stopColor="#9384FE" />
                          <stop offset="1" stopColor="#312EFE" />
                        </linearGradient>
                      </defs>
                    </svg>
                  </button>
                  <span className="ml-2 text-gray-700 mt-2">Youtube</span>
                </div>
                <div className="flex items-center mt-2">
                  <button>
                    <svg
                      width="36"
                      height="36"
                      viewBox="0 0 36 36"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <rect
                        x="0.5"
                        y="0.5"
                        width="35"
                        height="35"
                        rx="17.5"
                        stroke="url(#paint0_linear_55_157)"
                      />
                      <g clipPath="url(#clip0_55_157)">
                        <path
                          d="M27 26.9992V20.3992C27 17.1742 26.325 14.6992 22.5 14.6992C20.7 14.6992 19.5 15.6742 18.975 16.6492H18.9V14.9992H15.375V26.9992H19.125V21.0742C19.125 19.4992 19.425 17.9992 21.375 17.9992C23.25 17.9992 23.325 19.7992 23.325 21.1492V26.9992H27Z"
                          fill="url(#paint1_linear_55_157)"
                        />
                        <path
                          d="M9.29688 15H13.0469V27H9.29688V15Z"
                          fill="url(#paint2_linear_55_157)"
                        />
                        <path
                          d="M11.175 9C9.975 9 9 9.975 9 11.175C9 12.375 9.975 13.35 11.175 13.35C12.375 13.35 13.35 12.375 13.35 11.175C13.35 9.975 12.375 9 11.175 9Z"
                          fill="url(#paint3_linear_55_157)"
                        />
                      </g>
                      <defs>
                        <linearGradient
                          id="paint0_linear_55_157"
                          x1="11.4725"
                          y1="11.4725"
                          x2="31.0549"
                          y2="36"
                          gradientUnits="userSpaceOnUse"
                        >
                          <stop stopColor="#9384FE" />
                          <stop offset="1" stopColor="#312EFE" />
                        </linearGradient>
                        <linearGradient
                          id="paint1_linear_55_157"
                          x1="19.0797"
                          y1="18.619"
                          x2="25.8441"
                          y2="26.6267"
                          gradientUnits="userSpaceOnUse"
                        >
                          <stop stopColor="#9384FE" />
                          <stop offset="1" stopColor="#312EFE" />
                        </linearGradient>
                        <linearGradient
                          id="paint2_linear_55_157"
                          x1="10.4919"
                          y1="18.8242"
                          x2="15.0358"
                          y2="20.6027"
                          gradientUnits="userSpaceOnUse"
                        >
                          <stop stopColor="#9384FE" />
                          <stop offset="1" stopColor="#312EFE" />
                        </linearGradient>
                        <linearGradient
                          id="paint3_linear_55_157"
                          x1="10.3863"
                          y1="10.3863"
                          x2="12.7525"
                          y2="13.35"
                          gradientUnits="userSpaceOnUse"
                        >
                          <stop stopColor="#9384FE" />
                          <stop offset="1" stopColor="#312EFE" />
                        </linearGradient>
                        <clipPath id="clip0_55_157">
                          <rect
                            width="18"
                            height="18"
                            fill="white"
                            transform="translate(9 9)"
                          />
                        </clipPath>
                      </defs>
                    </svg>
                  </button>
                  <span className="ml-2 text-gray-700 mt-2">Linkedin</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
      <footer className="bg-gray-800 text-white py-4">
        <div className="container mx-auto text-center">
          <p>&copy; 2024 Techsouq. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default Footer;

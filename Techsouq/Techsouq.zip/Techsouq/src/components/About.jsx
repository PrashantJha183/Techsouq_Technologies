import React from "react";
import { useState } from 'react';
import About1 from "../assets/Images/About2.png";
import about from "../assets/Images/about.png";
import Shivani from "../assets/Team/shivani.jpg";
import Shifan from "../assets/Team/shifan.jpg";
import Kinjal from "../assets/Team/kinjal.jpg";
import Pravin from "../assets/Team/Pravin.jpg";
import Dipak from "../assets/Team/dipak.jpg";
import Prashant from "../assets/Team/Pranshant.jpg";
import Navbar_Main from "./Navbar_Main";
import Questions1 from "../pages/Questions1";
import Questions2 from "../pages/Questions2";
import Last_page from "../pages/Last_page";
import Footer from "./Footer";

const About = () => {
    const [activeIndex, setActiveIndex] = useState(0);

    const testimonials = [
        {
            name: 'Rajesh Kumar',
            title: 'Ceo Spotify corporate',
            quote: 'Seamless Experience and Exceptional Results! TechSouq Technologies completely transformed our outdated website into a modern, high-performing platform. Their team was responsive, professional, and delivered beyond our expectations. We’ve seen a 35% increase in traffic within the first month!' ,
            image: 'https://i.pravatar.cc/300',
        },
        {
            name: 'Anil Sharma',
            title: 'MNC Company',
            quote: "TechSouq Technologies completely transformed our outdated website into a modern, high-performing platform. Their team was responsive, professional, and delivered beyond our expectations. We’ve seen a 35% increase in traffic within the first month!" ,
            image: 'https://i.pravatar.cc/300',
        },
        {
            name: 'Priya Mehta',
            title: 'UI/UX Designer',
            quote: "The team at TechSouq is incredibly skilled and creative. They designed a logo for our business that perfectly encapsulates our values. I couldn’t be happier with their professionalism and quick turnaround!"  
,
            image: 'https://i.pravatar.cc/300',
        },
        {
            name: 'Deepika Rao',
            title: 'Company Owner',
            quote: "TechSouq Technologies helped us revamp our online store, making it faster and more user-friendly. Their expertise in e-commerce solutions was evident at every stage. We’ve seen a significant boost in sales since the relaunch!"  
,
            image: 'https://i.pravatar.cc/300',
        },
    ];

    const handlePrev = () => {
        setActiveIndex((prevIndex) =>
            prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
        );
    };

    const handleNext = () => {
        setActiveIndex((prevIndex) =>
            prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
        );
    };

    return (
        <>
            <Navbar_Main />
            <div className="relative h-screen">
                <div className="absolute inset-0 bg-black opacity-60 z-10"></div>
                <img
                    src={about}
                    className="absolute inset-0 w-full h-full object-cover z-0 rounded-br-6xl"
                    alt="Background"
                />
                <div className="flex flex-col items-center justify-center text-center text-white relative z-20 h-full px-4 sm:px-12">
                    <button className="btn px-4 py-2 sm:px-6 sm:py-3 border border-white rounded-full text-sm sm:text-base font-bold">
                        Welcome To Techsouq
                    </button>
                    <h1 className="text-4xl sm:text-6xl font-bold mt-4">
                        A captivating statement about your mission or value
                    </h1>
                    <h4 className="text-sm sm:text-base lg:text-lg mt-4 max-w-4xl">
                        At Techsouq, we believe in transforming ideas into digital excellence. Driven by creativity and defined by results, we combine innovation, design, and technology to empower businesses in the digital landscape.
                    </h4>
                    <button className="btn px-6 py-3 rounded-xl bg-white flex items-center space-x-2 mt-6">
                        <span className="bg-gradient-to-r from-[#9384FE] to-[#312EFE] text-transparent bg-clip-text font-bold text-sm sm:text-base">
                            Book a consultation
                        </span>
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                            strokeWidth={1.5}
                            stroke="url(#gradient1)"
                            className="w-5 h-5 sm:w-6 sm:h-6"
                        >
                            <defs >
                                <linearGradient id="gradient1" x1="0" x2="1" y1="0" y2="0">
                                    <stop offset="0%" stopColor="#9384FE" />
                                    <stop offset="100%" stopColor="#312EFE" />
                                </linearGradient>
                            </defs>
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M17.25 8.25 21 12m0 0-3.75 3.75M21 12H3"
                            />
                        </svg>
                    </button>
                </div>
            </div>
            <div className="max-w-screen-2xl container mx-auto xl:px-24 ">
                <div className="mt-10 flex flex-col md:flex-row-reverse items-center justify-between gap-2">
                    <div className="md:w-1/2 px-2 space-y-4">
                        <button className="font-semibold btn bg-gradient-to-r inline-block text-transparent bg-clip-text from-[#9384Ef] to-[#312EFE] px-6 py-3 text-xl border border-purple-700 rounded-full">
                            About Us
                        </button>
                        <div className="text-4xl sm:text-6xl font-bold">
                            Who We Are or Our Journey
                        </div>
                        <p className="text-[#4A4A4A] text-lg">
                            At Techsouq, we specialize in turning visions into reality. With a passion for design and innovation, we deliver cutting-edge solutions that empower businesses to thrive in the digital age. From crafting seamless user experiences to developing impactful web platforms, our mission is to create meaningful connections between brands and their audiences.
                        </p>
                        <div className="font-bold py-4">
                            Together, let's redefine what's possible in the digital world
                        </div>
                        <button className="bg-gradient-to-r from-[#9384Ef] to-[#312EFE] font-semibold btn text-white px-8 py-3 rounded-md flex justify-center gap-4 ">
                            Contact US Now
                            <svg
                                width="20"
                                height="20"
                                viewBox="0 0 20 20"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <g clipPath="url(#clip0_55_1110)">
                                    <path
                                        d="M0.953125 9.6377H16.7865"
                                        stroke="white"
                                        strokeWidth="2"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                    />
                                    <path
                                        d="M11.6641 4.16675L17.4974 10.0001L11.6641 15.8334"
                                        stroke="white"
                                        strokeWidth="2"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                    />
                                </g>
                                <defs>
                                    <clipPath id="clip0_55_1110">
                                        <rect width="20" height="20" fill="white" />
                                    </clipPath>
                                </defs>
                            </svg>
                        </button>
                    </div>
                    <div className="md:w-1/3">
                        <img src={About1} alt="" className="rounded-xl w-full" />
                    </div>
                </div>
            </div>
            <div className="container mx-auto py-16">
                <div className="text-center mb-16">
                    <button className="font-semibold btn bg-gradient-to-r inline-block text-transparent bg-clip-text from-[#9384Ef] to-[#312EFE] px-6 py-3 text-xl border border-purple-700 rounded-full">
                        Our Team
                    </button>
                    <h1 className="text-4xl font-bold text-gray-800 mt-4">Meet the Minds Behind Techsouq</h1>
                    <p className="text-lg text-gray-600 mt-4">Our team is passionate about helping you succeed.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {[
                        { name: 'Lukas', role: 'Co-Founder & Leiter Strategie', image: Shivani },
                        { name: 'Daniel', role: 'Co-Founder & Growth Manager', image: Shifan },
                        { name: 'Amelie', role: 'Account Management & Backoffice', image: Kinjal },
                        { name: 'Amelie', role: 'Account Management & Backoffice', image: Pravin },
                        { name: 'Amelie', role: 'Account Management & Backoffice', image: Dipak },
                        { name : 'Amelie', role: 'Account Management & Backoffice', image: Prashant },
                    ].map((member, index) => (
                        <div key={index} className="bg-slate-100 rounded-lg shadow-md p-6 text-center">
                            <img src={member.image} alt={member.name} className="w-full rounded-full mb-4"/>
                            <h2 className="text-xl font-bold text-gray-800">{member.name}</h2>
                            <p className="text-gray-600">{member.role}</p>
                        </div>
                    ))}
                </div>
            </div>

            <div className="container mx-auto px-4">
                <div className="text-center mb-10">
                    <button className="font-semibold btn bg-gradient-to-r inline-block text-transparent bg-clip-text from-[#9384Ef] to-[#312EFE] px-6 py-3 text-xl border border-purple-700 rounded-full">
                        Client Reviews
                    </button>
                    <h2 className="text-3xl font-bold text-gray-800 mt-4">
                        Our Professional Testimonial
                    </h2>
                </div>

                <div className="flex flex-col md:flex-row items-center justify-center gap-10">
                    <div className="bg-white rounded-lg shadow-2xl p-6 text-center">
                        <img
                            src={testimonials[activeIndex].image}
                            alt={testimonials[activeIndex].name}
                            className="w-24 h-24 rounded-full mx-auto mb-4"
                        />
                        <h3 className="text-xl font-semibold text-gray-800">
                            {testimonials[activeIndex].name}
                        </h3>
                        <p className="text-gray-600">{testimonials[activeIndex].title}</p>
                        <p className="mt-4 text-gray-500 italic">
                            "{testimonials[activeIndex].quote}"
                        </p>
                    </div>
                </div>

                <div className="flex justify-between mt-6">
                    <button
                        onClick={handlePrev}
                        className="bg-gradient-to-r from-[#9384Ef] to-[#312EFE] font-semibold btn text-white px-8 py-3 rounded-md flex justify-center gap-4 "
                    >
                        Previous
                    </button>
                    <button
                        onClick={handleNext}
                        className="bg-gradient-to-r from-[#9384Ef] to-[#312EFE] font-semibold btn text-white px-8 py-3 rounded-md flex justify-center gap-4 "
                    >
                        Next
                    </button>
                </div>
            </div>
            <Questions1 />
            <Questions2 />
            <Last_page />
            <Footer />
        </>
    );
};

export default About;
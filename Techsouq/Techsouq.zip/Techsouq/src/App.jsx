import { useState } from 'react'
import './App.css'
import { BrowserRouter } from 'react-router-dom';
import { Route,Routes} from 'react-router-dom';
import Navbar_Main from "./components/Navbar_Main.jsx";
import AboutUS from "../src/pages/AboutUS.jsx";
import Services from "../src/pages/Services.jsx";
import Footer from '../src/components/Footer.jsx';
import Questions1 from './pages/Questions1.jsx';
import Questions2 from './pages/Questions2.jsx';
import Phase from './pages/Phase.jsx';
import ContactUS from './components/ContactUs.jsx';
import Last_page from './pages/Last_page.jsx';
import LandingPage from './pages/LandingPage.jsx';
import About from './components/About.jsx';
import Service from './components/Service.jsx';
import Pricing from './components/Pricing.jsx';
import CaseStudy from './components/CaseStudy.jsx';

function App() {
  

  return (
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<LandingPage/>}/>
      <Route path="/about" element={<About/>}/>
      <Route path="/services" element={<Service/>}/>
      <Route path="/pricing" element={<Pricing/>}/>
      <Route path="/caseStudy" element={<CaseStudy/>}/>
      <Route path="/contact" element={<ContactUS/>} />
    </Routes>
    </BrowserRouter>
  )
}

export default App

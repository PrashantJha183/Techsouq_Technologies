import React from "react";
import Hero_Image from "../assets/Images/Hero_Image.png";
import Navbar_Main from "../components/Navbar_Main";
import AboutUS from "./AboutUS";
import Services from "./Services";
import ChooseUS from "./ChooseUS";
import Phase from "./Phase";
import Testimonial from "./Testimonial";
import Questions1 from "./Questions1";
import Questions2 from "./Questions2";
import Last_page from "./Last_page";
import Footer from "../components/Footer";

const LandingPage = () => {
  return (
    <>
      <Navbar_Main />
      <div className="max-w-screen-2xl container xl:px-24 ">
        <div className="py-15 flex flex-col md:flex-row-reverse items-center justify-between gap-2">
          {/* Image Section */}
          <div className="md:w-1/2 w-full">
            <img src={Hero_Image} alt="Hero" className="rounded-xl w-full h-auto" />
            <div className="flex flex-col md:flex-row items-center justify-around -mt-14 gap-4">
              
              
            </div>
          </div>

          {/* Text Section */}
          <div className="md:w-1/2 w-full px-4 space-y-7">
            <button className="font-semibold btn bg-gradient-to-r inline-block text-transparent bg-clip-text from-[#9384Ef] to-[#312EFE]  px-6 py-2 text-lg border border-purple-700 rounded-full mt-20">
              Welcome To Techsouq
            </button>
            <h2 className="md:text-7xl text-4xl font-bold md:leading-snug leading-snug">
              Transforming a Ideas into a{" "}
              <span className="bg-gradient-to-r inline-block text-transparent bg-clip-text from-[#9384Ef] to-[#312EFE]">
                Digital world
              </span>
            </h2>
            <p className="text-[#4A4A4A] text-base">
              Crafting intuitive designs that captivate and inspire. Building robust websites that elevate brands online. Empowering businesses with innovative digital solutions.
            </p>
            <button className="bg-gradient-to-r from-[#9384Ef] to-[#312EFE] font-semibold btn text-white px-8 py-3 rounded-md flex justify-center gap-4">
              Book a Consultation
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clipPath="url(#clip0_55_1110)">
                  <path d="M0.953125 9.6377H16.7865" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M11.6641 4.16675L17.4974 10.0001L11.6641 15.8334" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </g>
                <defs>
                  <clipPath id="clip0_55_1110">
                    <rect width="20" height="20" fill="white" />
                  </clipPath>
                </defs>
              </svg>
            </button>
          </div>
        </div>
      </div>
      <AboutUS />
      <Services />
      <ChooseUS />
      <Phase />
      <Testimonial />
      <Questions1 />
      <Questions2 />
      <Last_page />
      <Footer />
    </>
  );
};

export default LandingPage;
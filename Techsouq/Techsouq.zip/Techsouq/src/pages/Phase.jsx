import React from "react";
import Image from "../assets/Images/3.png";
import circlec from "../assets/Images/Ellipse 5.png";

function Phase() {
  return (
    <div className="max-w-screen-2xl container xl:px-24 mt-5">
      <div className="py-15 flex flex-col md:flex-row-reverse items-center justify-between gap-2">
        {/* img */}
        <div className="image w-full md:w-1/3 flex items-center justify-center relative">
          <div
            className="absolute inset-3 -z-10 rounded-xl"
            style={{
              background: "linear-gradient(135deg, #9384FE, #312EFE)",
              transform: "translate(6%, 9%)",
            }}
          ></div>
          <img
            src={Image}
            alt="Business Transformation"
            className="w-full h-auto object-cover rounded-lg shadow-lg"
          />
        </div>

        {/* texts */}
        <div className="md:w-1/2 px-4 space-y-7 mt-5">
          {/* <button className="font-semibold btn bg-gradient-to-r inline-block text-transparent bg-clip-textbg-gradient-to-r from-[#9384Ef] to-[#312EFE] bg-clip-text px-8 py-3 rounded-t-lg">
                Welcome to Techsouq
              </button> */}
          <button className="bg-gradient-to-r from-[#9384Ef] to-[#312EFE] text-white font-bold py-2 px-4 rounded-full">
            1. Discovery Phase
          </button>
          <button className="bg-gradient-to-r text-transparent bg-clip-textbg-gradient-to-r from-[#9384Ef] to-[#312EFE] bg-clip-text font-bold py-2 px-4 rounded-full border-r-4 border-blue-500">
            2.
          </button>
          <button className="bg-gradient-to-r text-transparent bg-clip-textbg-gradient-to-r from-[#9384Ef] to-[#312EFE] bg-clip-text font-bold py-2 px-4 rounded-full border-r-4 border-blue-500">
            3.
          </button>
          <button className="bg-gradient-to-r text-transparent bg-clip-textbg-gradient-to-r from-[#9384Ef] to-[#312EFE] bg-clip-text font-bold py-2 px-4 rounded-full border-r-4 border-blue-500">
            4.
          </button>
          <h2 className="md:text-7xl text-4xl font-bold md:leading-snug leading-snug">
            Understanding Your Needs
            {/* <span className="bg-gradient-to-r text-transparent bg-clip-textbg-gradient-to-r from-[#9384Ef] to-[#312EFE] bg-clip-text text-6xl mt-2">
              Digital Success Story
            </span> */}
          </h2>
          <div className="mb-4">
            <div className="flex items-center">
              <svg
                width="20"
                height="20"
                viewBox="0 0 18 18"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <g clip-path="url(#clip0_55_608)">
                  <path
                    d="M16.5 8.30999V8.99999C16.4991 10.6173 15.9754 12.191 15.007 13.4864C14.0386 14.7817 12.6775 15.7293 11.1265 16.1879C9.57557 16.6465 7.91794 16.5914 6.40085 16.0309C4.88376 15.4704 3.58849 14.4346 2.70822 13.0778C1.82795 11.721 1.40984 10.116 1.51626 8.50223C1.62267 6.88841 2.24791 5.35223 3.29871 4.12279C4.34951 2.89335 5.76959 2.03653 7.34714 1.6801C8.92469 1.32367 10.5752 1.48674 12.0525 2.14499"
                    stroke="url(#paint0_linear_55_608)"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                  <path
                    d="M16.5 3L9 10.5075L6.75 8.2575"
                    stroke="url(#paint1_linear_55_608)"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </g>
                <defs>
                  <linearGradient
                    id="paint0_linear_55_608"
                    x1="6.28022"
                    y1="6.27592"
                    x2="14.4396"
                    y2="16.4957"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stop-color="#9384FE" />
                    <stop offset="1" stop-color="#312EFE" />
                  </linearGradient>
                  <linearGradient
                    id="paint1_linear_55_608"
                    x1="9.85714"
                    y1="5.3925"
                    x2="13.5938"
                    y2="11.4708"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stop-color="#9384FE" />
                    <stop offset="1" stop-color="#312EFE" />
                  </linearGradient>
                  <clipPath id="clip0_55_608">
                    <rect width="18" height="18" fill="white" />
                  </clipPath>
                </defs>
              </svg>

              <span className="ml-2 text-gray-700">
              Initial Consultation: We start with a conversation to understand your goals, challenges, and vision.  

              </span>
            </div>
            <div className="flex items-center">
              <svg
                width="20"
                height="20"
                viewBox="0 0 18 18"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <g clip-path="url(#clip0_55_608)">
                  <path
                    d="M16.5 8.30999V8.99999C16.4991 10.6173 15.9754 12.191 15.007 13.4864C14.0386 14.7817 12.6775 15.7293 11.1265 16.1879C9.57557 16.6465 7.91794 16.5914 6.40085 16.0309C4.88376 15.4704 3.58849 14.4346 2.70822 13.0778C1.82795 11.721 1.40984 10.116 1.51626 8.50223C1.62267 6.88841 2.24791 5.35223 3.29871 4.12279C4.34951 2.89335 5.76959 2.03653 7.34714 1.6801C8.92469 1.32367 10.5752 1.48674 12.0525 2.14499"
                    stroke="url(#paint0_linear_55_608)"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                  <path
                    d="M16.5 3L9 10.5075L6.75 8.2575"
                    stroke="url(#paint1_linear_55_608)"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </g>
                <defs>
                  <linearGradient
                    id="paint0_linear_55_608"
                    x1="6.28022"
                    y1="6.27592"
                    x2="14.4396"
                    y2="16.4957"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stop-color="#9384FE" />
                    <stop offset="1" stop-color="#312EFE" />
                  </linearGradient>
                  <linearGradient
                    id="paint1_linear_55_608"
                    x1="9.85714"
                    y1="5.3925"
                    x2="13.5938"
                    y2="11.4708"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stop-color="#9384FE" />
                    <stop offset="1" stop-color="#312EFE" />
                  </linearGradient>
                  <clipPath id="clip0_55_608">
                    <rect width="18" height="18" fill="white" />
                  </clipPath>
                </defs>
              </svg>

              <span className="ml-2 text-gray-700 mt-2">
              Industry Analysis: Our team researches your industry, competitors, and target audience to craft a solution that gives you a competitive edge.  

              </span>
            </div>
            <div className="flex items-center">
              <svg
                width="18"
                height="18"
                viewBox="0 0 18 18"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <g clip-path="url(#clip0_55_608)">
                  <path
                    d="M16.5 8.30999V8.99999C16.4991 10.6173 15.9754 12.191 15.007 13.4864C14.0386 14.7817 12.6775 15.7293 11.1265 16.1879C9.57557 16.6465 7.91794 16.5914 6.40085 16.0309C4.88376 15.4704 3.58849 14.4346 2.70822 13.0778C1.82795 11.721 1.40984 10.116 1.51626 8.50223C1.62267 6.88841 2.24791 5.35223 3.29871 4.12279C4.34951 2.89335 5.76959 2.03653 7.34714 1.6801C8.92469 1.32367 10.5752 1.48674 12.0525 2.14499"
                    stroke="url(#paint0_linear_55_608)"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                  <path
                    d="M16.5 3L9 10.5075L6.75 8.2575"
                    stroke="url(#paint1_linear_55_608)"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </g>
                <defs>
                  <linearGradient
                    id="paint0_linear_55_608"
                    x1="6.28022"
                    y1="6.27592"
                    x2="14.4396"
                    y2="16.4957"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stop-color="#9384FE" />
                    <stop offset="1" stop-color="#312EFE" />
                  </linearGradient>
                  <linearGradient
                    id="paint1_linear_55_608"
                    x1="9.85714"
                    y1="5.3925"
                    x2="13.5938"
                    y2="11.4708"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stop-color="#9384FE" />
                    <stop offset="1" stop-color="#312EFE" />
                  </linearGradient>
                  <clipPath id="clip0_55_608">
                    <rect width="18" height="18" fill="white" />
                  </clipPath>
                </defs>
              </svg>

              <span className="ml-2 text-gray-700 mt-2">
              Requirement Gathering: We collaborate with you to define project objectives, scope, and success criteria. 
              </span>
            </div>
            <div className="flex items-center">
              <svg
                width="20"
                height="20"
                viewBox="0 0 18 18"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <g clip-path="url(#clip0_55_608)">
                  <path
                    d="M16.5 8.30999V8.99999C16.4991 10.6173 15.9754 12.191 15.007 13.4864C14.0386 14.7817 12.6775 15.7293 11.1265 16.1879C9.57557 16.6465 7.91794 16.5914 6.40085 16.0309C4.88376 15.4704 3.58849 14.4346 2.70822 13.0778C1.82795 11.721 1.40984 10.116 1.51626 8.50223C1.62267 6.88841 2.24791 5.35223 3.29871 4.12279C4.34951 2.89335 5.76959 2.03653 7.34714 1.6801C8.92469 1.32367 10.5752 1.48674 12.0525 2.14499"
                    stroke="url(#paint0_linear_55_608)"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                  <path
                    d="M16.5 3L9 10.5075L6.75 8.2575"
                    stroke="url(#paint1_linear_55_608)"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </g>
                <defs>
                  <linearGradient
                    id="paint0_linear_55_608"
                    x1="6.28022"
                    y1="6.27592"
                    x2="14.4396"
                    y2="16.4957"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stop-color="#9384FE" />
                    <stop offset="1" stop-color="#312EFE" />
                  </linearGradient>
                  <linearGradient
                    id="paint1_linear_55_608"
                    x1="9.85714"
                    y1="5.3925"
                    x2="13.5938"
                    y2="11.4708"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stop-color="#9384FE" />
                    <stop offset="1" stop-color="#312EFE" />
                  </linearGradient>
                  <clipPath id="clip0_55_608">
                    <rect width="18" height="18" fill="white" />
                  </clipPath>
                </defs>
              </svg>

              <span className="ml-2 text-gray-700 mt-2">
              Idea Validation: Before proceeding, we validate concepts to ensure alignment with your business strategy
              </span>
            </div>
          </div>
          <button className="bg-gradient-to-r from-[#9384Ef] to-[#312EFE] font-semibold btn text-white px-8 py-3 rounded-md flex justify-center gap-4">
            Book a Consultation
            <svg
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <g clip-path="url(#clip0_55_1110)">
                <path
                  d="M0.953125 9.6377H16.7865"
                  stroke="white"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
                <path
                  d="M11.6641 4.16675L17.4974 10.0001L11.6641 15.8334"
                  stroke="white"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </g>
              <defs>
                <clipPath id="clip0_55_1110">
                  <rect width="20" height="20" fill="white" />
                </clipPath>
              </defs>
            </svg>
          </button>
          
        </div>
      </div>
    </div>
  );
}

export default Phase;
